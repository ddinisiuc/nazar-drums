
<!-- Header
================================================== -->

<div id="main-header">
	<div class="container">

		<div class="row">
			<div class="header">

				<div class="col-md-2 col-sm-12">
					<div id="logo" class="margin-top-25">
						<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(Voyager::image(setting('index.logo'))); ?>" alt=""></a><br>
					</div>
				</div>

				<!-- Search Form -->
				<div class="search-container">
					  <form action="#" method="get">
						  <input type="text" name="s" id="s" onblur="if(this.value=='')this.value='to search type and hit enter';" onfocus="if(this.value=='to search type and hit enter')this.value='';" value="to search type and hit enter" />
					  </form>
					  <div class="close-search"><a class="sl sl-icon-close" href="#"></a></div>
				</div>

				<div class="col-md-10 col-sm-12">

					<!-- Mobile Navigation -->
					<div class="menu-responsive">
						<i class="fa fa-reorder menu-trigger"></i>

						  <form action="#" method="get" class="responsive-search">
							  <input type="text" onblur="if(this.value=='')this.value='to search type and hit enter';" onfocus="if(this.value=='to search type and hit enter')this.value='';" value="to search type and hit enter" />
						  </form>
					</div>

						<!-- Main Navigation -->
						<nav id="navigation">
                            <?php $current = Route::currentRouteName(); ?>
							<ul class="menu alt2" id="responsive">
								<li class="dropdown">
									<a href="<?php echo e(route('home')); ?>" <?php if(Route::currentRouteName() == 'home'): ?> class="current" <?php endif; ?>>Home</a>
								</li>
								<li class="dropdown">
									<a onclick="return false" href="#" <?php if($current == 'project'): ?> class="current" <?php endif; ?>>My projects</a>
									<ul>
                                        <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <li>
                                                <a href="<?php echo e(route('project', $item->slug)); ?>"><?php echo e($item->title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                        <?php endif; ?>
									</ul>
								</li>
								<li class="dropdown" >
									<a href="<?php echo e(route('shop')); ?>" <?php if($current == 'shop'): ?> class="current" <?php endif; ?>>Shop</a>
								</li>

								<li>
									<a href="<?php echo e(route('blog')); ?>" <?php if($current == 'blog'): ?> class="current" <?php endif; ?>>Blog</a>
								</li>
								<li>
									<a href="<?php echo e(route('about-me')); ?>" <?php if($current == 'about-me'): ?> class="current" <?php endif; ?>>about-me</a>
								</li>

								<li>
									<a href="<?php echo e(route('contact')); ?>" <?php if($current == 'contact'): ?> class="current" <?php endif; ?>>Contact</a>
								</li>
							</ul>
						</nav>

				</div>
				<div class="clearfix"></div>
			</div>
		</div>

	</div>
</div>
<?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/layouts/includes/header.blade.php ENDPATH**/ ?>