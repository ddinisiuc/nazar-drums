<?php $__env->startSection('content'); ?>

<div id="header-container" data-color="#202122" data-color-opacity="1">
<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Titlebar
================================================== -->
	<div id="titlebar" class="centered margin-bottom-0">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2><?php echo e($page->title); ?></h2>
				    <span><?php echo e($page->excerpt); ?></span>
				</div>
			</div>
		</div>
	</div>
</div>

<!-- Content
================================================== -->

<!-- Projects -->
<div class="gutter-30px isotope-four-cols blog-wrapper isotope-wrapper fw">
	<div class="isotope-sizer"></div>
    <!-- Item -->
    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="isotope-item">
            <!-- Post -->
            <div class="post-container">
                <div class="post-img">
                    <a href="<?php echo e(route('blog_detail', $item->slug)); ?>" class="img-hover">
                        <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="">
                    </a>
                </div>
                <div class="post-content">
                    <!-- Categories -->
                    <ul class="post-categories">
                        <li><a href="#"><?php echo e(strftime("%B %d, %Y", strtotime($item->created_at))); ?></a></li>
                    </ul>
                    <!-- Meta -->
                    <a href="#"><h3><?php echo e($item->title); ?></h3></a>
                    <p><?php echo e($item->excerpt); ?></p>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Постов пока нету</p>
    <?php endif; ?>
</div>
<!-- Isotope Wrapper / End -->

<!-- Pagination -->
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<!-- Pagination -->
			<div class="pagination-container margin-top-50 margin-bottom-0">
				<nav class="pagination">
					<ul>
                        <li><a href="<?php echo e($posts->previousPageUrl()); ?>"><i class="sl sl-icon-arrow-left"></i></a></li>
                        <?php for($i = 1; $i <= $posts->lastPage(); $i++): ?>
                            <li><a href="<?php echo e($posts->url($i)); ?>" class="current-page"><?php echo e($i); ?></a></li>
                        <?php endfor; ?>
                        <li><a href="<?php echo e($posts->nextPageUrl()); ?>"><i class="sl sl-icon-arrow-right"></i></a></li>
                    </ul>
				</nav>
			</div>
		</div>
	</div>
    <div class="clearfix"></div>

			<div class="margin-top-50"></div>


			<div class="clearfix"></div>
			<div class="margin-top-35"></div>
            </div>
</div>
<!-- Pagination / End -->
<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/blog/index.blade.php ENDPATH**/ ?>