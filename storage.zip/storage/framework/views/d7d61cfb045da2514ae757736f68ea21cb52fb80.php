<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Content
================================================== -->

<!-- Parallax Full-Screen Background -->
<div class="fullscreen background parallax" data-background="<?php echo e(asset('images/portfolio-slide-01.jpg')); ?>" data-img-width="1800" data-img-height="1202" data-diff="300" data-color="#303133" data-color-opacity="0.9">
    <div class="parallax-content-container">
        <div class="parallax-content">
            <h2><?php echo e($project->title); ?></h2>
            <div class="scroll-to-content bounce ln ln-icon-Down-3"></div>
        </div>
    </div>
</div>

<br>

<!-- Content -->
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <div class="project-details margin-top-45 margin-bottom-0">
                <h4><?php echo e($project->title); ?></h4>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-8">
            <?php echo $project->excerpt; ?>

        </div>

        <div class="col-md-4">
            <ul class="details alt2">
                <li><span>Дата создания проекта:</span><?php echo e(strftime("%B %d, %Y", strtotime($project->created_at))); ?> </li>
                <li><span>Локация:</span> <?php echo e($project->location); ?></li>
                
            </ul>
        </div>
    </div>

</div>

<!-- Image Edge -->
<div class="image-edge margin-top-80">

    <div class="image-edge-content">
        <?php echo $project->description; ?>

    </div>

    <div class="edge-bg" data-background-image="<?php echo e(Voyager::image($project->image_one)); ?>"></div>

</div>
<!-- Image Edge / End -->

<!-- Image Edge -->
<div class="image-edge left margin-top-0">

    <div class="image-edge-content">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $project_benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 col-sm-6">
                    <div class="icon-box-1">
                        <i class="ln <?php echo e($item->icons); ?>"></i>
                        <h4><?php echo e($item->title); ?></h4>
                        <?php echo $item->description; ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <?php endif; ?>
        </div>
    </div>

    <div class="edge-bg" data-background-image="<?php echo e(Voyager::image($project->image_two)); ?>"></div>

</div>
<!-- Image Edge / End -->

<!-- Back To Top Button -->
<div id="backtotop">
    <a href="#"></a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/project.blade.php ENDPATH**/ ?>