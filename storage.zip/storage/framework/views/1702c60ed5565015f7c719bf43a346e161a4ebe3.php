<?php $__env->startSection('content'); ?>
<div id="header-container" data-background="images/blog-post-header.jpg" data-color="#303133"data-color-opacity="0.6">
    <?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Titlebar
    ================================================== -->
    <div id="titlebar" class="single-post-titlebar">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <!-- Title -->
                        <h2><?php echo e($blog_detail->title); ?></h2>

                        <!-- Meta Tags -->
                        <div class="meta-tags">
                            <span><?php echo e(strftime("%B %d, %Y", strtotime($blog_detail->created_at))); ?></span>
                            
                            <span>by <a href="#"><?php echo e($admin['name']); ?></a></span>
                        </div>

                        <!-- Nav -->
                        <ul id="portfolio-nav">
                            <li class="next"><a href="#" class="tooltip left" title="Next Post"><i
                                        class="sl sl-icon-arrow-right"></i></a></li>
                            <li class="prev"><a href="#" class="tooltip right" title="Previous Posts"><i
                                        class="sl sl-icon-arrow-left"></i></a></li>
                        </ul>

                    </div>
                </div>
            </div>
        </div>

    </div>
		<div class="clearfix"></div>

		<!-- Content
================================================== -->
		<div class="container">
			<div class="row">

				<!-- Post Content -->
				<div class="single-post-content">

					<div class="col-md-10 col-md-offset-1">
						<h2><?php echo e($blog_detail->subtitle); ?></h2>
						<p><?php echo e($blog_detail->excerpt); ?></p>
					</div>

                    <?php if($blog_detail->gallery): ?>

                        <!-- Photo Grid -->
                        <div class="col-md-12">
                            <div class="photoGrid  big clearfix margin-top-40 margin-bottom-0">
                                <?php $__empty_1 = true; $__currentLoopData = json_decode($blog_detail->gallery); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <a class="item mfp-gallery zoom-hover" href="<?php echo e(Voyager::image($item)); ?>">
                                    <img src="<?php echo e(asset('images/blog-grid-01.jpg')); ?>" alt="">
                                </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>


					<div class="col-md-10 col-md-offset-1">
						<h3><?php echo e($blog_detail->subtitle_three); ?></h3>
						<?php echo $blog_detail->body; ?>

					</div>

				</div>

				<!-- Others -->
				<div class="col-md-10 col-md-offset-1">

					<!-- Related Posts -->
					<h3 class="headline margin-top-65">Похожие посты</h3>
					<div class="gutter-30px isotope-three-cols isotope-wrapper no-animation related-posts">

						<div class="isotope-sizer"></div>

						<!-- Item -->
						<?php $__empty_1 = true; $__currentLoopData = $related_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="isotope-item">
                                <!-- Post -->
                                <div class="post-container">
                                    <div class="post-img related_post_img">
                                        <a href="<?php echo e(route('blog_detail', $item->slug)); ?>" class="img-hover">
                                            <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="">
                                        </a>
                                    </div>
                                    <div class="post-content">
                                        <!-- Categories -->
                                        <ul class="post-categories">
                                            <li><a href="<?php echo e(route('blog_detail', $item->slug)); ?>"><?php echo e(strftime("%B %d, %Y", strtotime($item->created_at))); ?></a></li>
                                        </ul>
                                        <!-- Meta -->
                                        
                                        <a href="<?php echo e(route('blog_detail', $item->slug)); ?>">
                                            <h3><?php echo e($item->title); ?></h3>
                                        </a>
                                        <p><?php echo e($item->excerpt); ?></p>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <?php endif; ?>

					</div>
					<!-- Related Posts / End -->

					<div class="clearfix"></div>

					<div class="margin-top-50"></div>


					<div class="clearfix"></div>
					<div class="margin-top-35"></div>
				</div>

			</div>
		</div>
		<!-- Container / End -->
		<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/blog/blog-detail.blade.php ENDPATH**/ ?>