<?php $__env->startSection('content'); ?>
<div id="header-container" data-background="<?php echo e(asset('images/shop-parallax.jpg')); ?>" data-color="#303133"  data-color-opacity="0.7">
<?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Titlebar
================================================== -->
<div id="titlebar" class="centered">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2><?php echo e($product_detail->title); ?></h2>
			</div>
		</div>
	</div>
</div>

</div>
<div class="clearfix"></div>
<!-- Content
================================================== -->
<div class="container">

	<div class="row">
		<div class="col-md-12">
			<div class="simple-slider">
				<ul class="slides">
					<?php $gallery = json_decode($product_detail->gallery) ?>
                    <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					    <li><img src="<?php echo e(Voyager::image($item)); ?>" alt=""/></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <?php endif; ?>
				</ul>
			</div>
		</div>
	</div>

	<div class="row vanilla-content">

		<div class="col-md-12">
			<h3 class="margin-top-45 margin-bottom-30">Описание продукта</h3>
		</div>

		<div class="col-md-8">
				<?php echo $product_detail->description; ?>

		</div>

		<div class="col-md-4">
			<ul class="details alt">
				<li><span>Название инструмента:</span> <?php echo e($product_detail->title); ?></li>
				<li><span>Цена:</span> $<?php echo e($product_detail->price); ?></li>
				
			</ul>
            <?php if($product_detail->youtube): ?>
                <a href="<?php echo e($product_detail->youtube); ?>" target="_blank" class="button fw medium border margin-top-15">Просмотреть в Youtube</a>
            <?php endif; ?>
		</div>
	</div>

</div>
  <!-- Container / Start -->
<section>
<div class="container">

<div class="row">

	<!-- Contact Form -->
	<div class="col-md-8 col-md-offset-2">

		<section id="contact">
			<h3 class="headline centered margin-bottom-45">Связаться</h3>

			<div id="contact-message"></div>

				<form method="post" action="<?php echo e(route('send_order')); ?>" name="contactform" id="contactform" autocomplete="on">
                    <?php echo csrf_field(); ?>
				<div class="row">
					<div class="col-md-6">
						<div>
							<input name="name" type="text" id="name" placeholder="Your Name" required="required" />
						</div>
					</div>

					<div class="col-md-6">
						<div>
							<input name="email" type="email" id="email" placeholder="Email Address" pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$" required="required" />
						</div>
					</div>
				</div>

				<div class="form-group col-md-14">
      					<select name="product_id" id="inputState" class="form-control">
                            <option  selected>Choose...</option>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        					    <option <?php if($product_detail->slug == $item->slug): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <?php endif; ?>
      					</select>
    			</div>
				<div>
					<textarea name="message" cols="40" rows="3" id="comments" placeholder="Message" spellcheck="true" required="required"></textarea>
				</div>

				<input type="submit" class="submit button border center margin-top-10" id="submit" value="Submit Message" />

				</form>
		</section>
	</div>
</section>
	<!-- Contact Form / End -->
<section>
		<!-- Logo Carousel 2 -->
		<div class="container">
	<div class="row">
		<div class="col-md-12">
			<h3 class="headline left with-border margin-top-60 margin-bottom-50">Похожие инструменты</h3>
		</div>
    </div>
    
	<div class="row">
		<div class="col-md-12">

			<!-- Carousel -->
			<div class="logo-carousel-alt">
                <?php $__empty_1 = true; $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			        <div class="item"><img src="<?php echo e(Voyager::image($item->image)); ?>" alt=""/></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <?php endif; ?>
			</div>

		</div>
	</div>
</div>
</section>
<!-- Logo Carousel 2 / End -->

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/shop/product_detail.blade.php ENDPATH**/ ?>