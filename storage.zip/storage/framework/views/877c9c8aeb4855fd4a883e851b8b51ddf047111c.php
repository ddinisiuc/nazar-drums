<?php $__env->startSection('content'); ?>
<div id="header-container" data-background="<?php echo e(asset('images/shop-parallax.jpg')); ?>" data-color="#303133" data-color-opacity="0.7">
    <?php echo $__env->make('layouts.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Titlebar
================================================== -->
    <div id="titlebar" class="centered">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo e($page->title); ?></h2>
                    <span><?php echo e($page->excerpt); ?></span>
                </div>
            </div>
        </div>
    </div>

</div>
<div class="clearfix"></div>

<!-- Content
================================================== -->

<div class="container">
    <div class="row">

        <!-- Widgets -->
        <div class="col-md-3 col-sm-4">

            <!-- Price Range -->
            <div class="widget margin-bottom-50">
                <div class="headline no-margin">
                    <h4>Категории</h4>
                </div>
                <ul class="list-group category_list">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <a href="<?php echo e($item->slug); ?>" style="text-decoration: none;"> <?php echo e($item->title); ?></a>
                            <span class="badge badge-primary badge-pill"><?php echo e(count($item->products)); ?></span>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </ul>
            </div>

            <!-- Recent Posts -->
            <div class="widget margin-bottom-50">
                <h4>Popular Products</h4>
                <ul class="widget-tabs shop">
                    <?php $__empty_1 = true; $__currentLoopData = $popular_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li>
                            <div class="widget-content">
                                <div class="widget-thumb">
                                    <a href="<?php echo e(route('product_detail', $item->slug)); ?>"><img src="<?php echo e(Voyager::image($item->image)); ?>" alt="" /></a>
                                </div>
                                <div class="widget-text">
                                    <h5><a href="#"><?php echo e($item->title); ?></a></h5>
                                    <span>
                                        <?php if($item->old_price): ?>
                                            <del>$<?php echo e($item->old_price); ?></del>
                                        <?php endif; ?>
                                        <mark>$<?php echo e($item->price); ?></mark>
                                    </span>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </ul>
            </div>

            <div class="clearfix"></div>
            <div class="margin-bottom-40"></div>
        </div>
        <!-- Widgets / End -->

        <!-- Products -->
        <div class="col-md-9 col-sm-8">

            <p class="margin-bottom-25 margin-left-10">Showing 1–9 of 23 results</p>

            <div class="row isotope-wrapper isotope-three-cols extra-gutter-left shop-wrapper">

                <div class="isotope-sizer"></div>

                <!-- Product -->
                <?php if($products->isNotEmpty()): ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-xs-12 isotope-item">
                            <div class="shop-item">
                                <a href="<?php echo e(route('product_detail', $item->slug)); ?>">
                                    <img src="<?php echo e(Voyager::image($item->image)); ?>" alt="" />
                                </a>
                                <figure>
                                    <figcaption class="item-description">
                                        <a href="<?php echo e(route('product_detail', $item->slug)); ?>"><h5><?php echo e($item->title); ?></h5></a>
                                        <span class="sale">
                                            <?php if($item->old_price): ?>
                                                <del>$<?php echo e($item->old_price); ?></del>
                                            <?php endif; ?>
                                            <mark>$<?php echo e($item->price); ?></mark>
                                        </span>
                                    </figcaption>
                                </figure>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <!-- Pagination -->
                    <div class="pagination-container margin-top-20 margin-bottom-0">
                        <nav class="pagination">
                            <ul>
                                <li><a href="<?php echo e($products->previousPageUrl()); ?>"><i class="sl sl-icon-arrow-left"></i></a></li>
                                <?php for($i = 1; $i <= $products->lastPage(); $i++): ?>
                                    <li><a href="<?php echo e($products->url($i)); ?>" class="current-page"><?php echo e($i); ?></a></li>
                                <?php endfor; ?>
                                <li><a href="<?php echo e($products->nextPageUrl()); ?>"><i class="sl sl-icon-arrow-right"></i></a></li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>

        </div>
        <!-- Products -->

    </div>
</div>
<!-- Container / End -->
<!-- Back To Top Button -->
<div id="backtotop">
    <a href="#"></a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/shop/products.blade.php ENDPATH**/ ?>