<!DOCTYPE html>
<html lang="ru">
<head>

<!-- Basic Page Needs
================================================== -->
<meta charset="utf-8">
<title>Sphene</title>

<!-- Mobile Specific Metas
================================================== -->
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('/css/style.css')); ?>">
<link rel="stylesheet" type="text/css"  href="<?php echo e(asset('/css/colors/blue.css')); ?>" id="colors">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>">
     <title>Nazar-Drums</title>
</head>
<body>
    <div id="loader-wrapper">
        <div id="loader"></div>
    </div>
    <div id="wrapper">

        <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layouts.includes.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\Danik\Laravel&Compouser\openServer\OSPanel\domains\Nazar\nazar-drums\resources\views/layouts/app.blade.php ENDPATH**/ ?>